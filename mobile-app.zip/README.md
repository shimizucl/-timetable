# 手机独立版部署

这个文件夹里的 `index.html` 就是课表程序，只是增加了 PWA 支持。部署一次后，手机打开网址就能用，可以添加到桌面，第一次加载后断网也能打开，不需要电脑一直开着。

## 方式一：Netlify Drop（最快）

1. 电脑浏览器打开 https://app.netlify.com/drop
2. 把整个 `mobile-app` 文件夹拖进去。
3. 页面会给出一个 `https://...netlify.app` 网址。
4. 手机浏览器打开这个网址，菜单里选择“添加到主屏幕”。

这种方式适合先测试。要长期保留，可以在 Netlify 注册一个免费账号并认领这个站点。

## 方式二：GitHub Pages（永久免费）

1. 注册并登录 https://github.com
2. 新建一个仓库，例如 `my-timetable`，设为 Public。
3. 把 `mobile-app` 文件夹里的所有文件上传到仓库根目录。
4. 进入仓库 `Settings → Pages`。
5. `Build and deployment` 选择 `Deploy from a branch`，分支选 `main`，目录选 `/ (root)`，保存。
6. 等 1 到 2 分钟，网址是 `https://你的用户名.github.io/my-timetable/`。
7. 手机打开网址，选择“添加到主屏幕”。

## 方式三：Cloudflare Pages / Vercel

两个平台都可以直接上传静态文件夹，操作和 Netlify 类似，注册免费账号后按页面提示上传 `mobile-app` 文件夹即可。

## 说明

- 课表数据保存在手机浏览器本地，不会上传到服务器。
- 换手机或清理浏览器数据前，请在课表程序里使用“数据 → 导出备份”。
- 学校课表导入可以在手机浏览器里使用复制粘贴，或使用 `mobile-bookmarklet.txt` 的书签代码。
